﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Collections;

namespace Preprocess
{
    public partial class Form1 : Form
    {
        private static string workPath = null;
        private static string batName = "temp.bat";
        private static string confPath = "D:\\unzip_conf.txt";

        public Form1()
        {
            readConf();
            InitializeComponent();
            label3.Enabled = false;
            OCRPath.Enabled = false;
            button3.Enabled = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if ("".Equals(rarExePath.Text) || !fileExistTest(rarExePath.Text))
            {
                MessageBox.Show("WinRAR.exe文件路径异常！");
                return;
            }
            if ("".Equals(rarPath.Text))
            {
                MessageBox.Show("压缩文件路径异常!");
                return;
            }
            if (directoryExistTest(rarPath.Text))
            {
                createBat(rarPath.Text);
            }
            else if (fileExistTest(rarPath.Text))
            {
                if (!rarPath.Text.Contains('.'))
                {
                    MessageBox.Show("压缩文件路径异常!");
                    return;
                }
                string filePath = rarPath.Text.Substring(0, rarPath.Text.LastIndexOf('.'));
                createBat(filePath);
            }
            else
            {
                MessageBox.Show("压缩文件路径异常!");
                return;
            }

            execBat(workPath + batName);
            delTmpFile(workPath + batName);

            if (enableOCR.Checked)
            {
                if (!fileExistTest(OCRPath.Text))
                {
                    MessageBox.Show("OCR工具路径异常！");
                    return;
                }
                
                ArrayList names = getAllFilesName(workPath);
                names.Insert(0, "\"" + OCRPath.Text + "\"");
                string[] names1 = (string[]) names.ToArray(typeof(string));
                File.WriteAllText(workPath + batName, String.Join(" ", names1));
                execBat(workPath + batName);
                delTmpFile(workPath + batName);
            }
        }

        private ArrayList getAllFilesName(string path)
        {
            DirectoryInfo root = new DirectoryInfo(path);
            ArrayList currentFiles = new ArrayList();

            foreach (FileInfo fi in root.GetFiles())
            {
                currentFiles.Add(fi.FullName);
            }

            foreach (DirectoryInfo di in root.GetDirectories())
            {
                foreach (string name in getAllFilesName(di.FullName))
                {
                    currentFiles.Add(name);
                }
            }
            return currentFiles;
        }

        private void createBat(string path)
        {
            workPath = path.EndsWith("\\") ? path : path + "\\";
            StringBuilder sb = new StringBuilder();
            FileInfo fi = new FileInfo(workPath + batName);

            if (!path.Equals(rarPath.Text))
            {
                new DirectoryInfo(path).Create();
                sb.Append("move " + rarPath.Text + " " + path + "\n");
            }

            sb.Append("set srcPath=\"" + workPath + "\"" + "\n");
            sb.Append("set rarPath=\"" + rarExePath.Text + "\"" + "\n");
            sb.Append("for /r %srcPath% %%i in (*.rar) do %rarPath% x -y \"%%i\" \"%%~dpi\" && del \"%%i\" > nul" + "\n");
            sb.Append("for /r %srcPath% %%i in (*.zip) do %rarPath% x -y \"%%i\" \"%%~dpi\" && del \"%%i\" > nul" + "\n");
            sb.Append("for /r %srcPath% %%i in (*.rar) do %rarPath% x -y \"%%i\" \"%%~dpi\" && del \"%%i\" > nul" + "\n");
            sb.Append("for /r %srcPath% %%i in (*.zip) do %rarPath% x -y \"%%i\" \"%%~dpi\" && del \"%%i\" > nul" + "\n");
            sb.Append("exit 0");

            File.WriteAllText(fi.FullName, sb.ToString());
        }

        private void execBat(string batPath)
        {
            Process pro = new Process();
            pro.StartInfo.FileName = batPath;
            pro.StartInfo.UseShellExecute = false;
            pro.StartInfo.RedirectStandardInput = false;
            pro.StartInfo.RedirectStandardOutput = true;
            pro.Start();
            string result = pro.StandardOutput.ReadToEnd();
            Console.WriteLine(result);
            pro.WaitForExit();
        }

        private void delTmpFile(string path)
        {
            FileInfo fi = new FileInfo(path);
            fi.Delete();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.rarExePath.SelectedText = dialog.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.rarPath.SelectedText = dialog.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                this.OCRPath.SelectedText = dialog.FileName;
            }
        }

        private void rarPath_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.All;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void rarPath_DragDrop(object sender, DragEventArgs e)
        {
            string fname = ((System.Array)e.Data.GetData(DataFormats.FileDrop)).GetValue(0).ToString();
            rarPath.Text = fname;
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            rarPath_DragEnter(sender, e);
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            rarPath_DragDrop(sender, e);
        }

        private void enableOCR_CheckedChanged(object sender, EventArgs e)
        {
            if (enableOCR.Checked)
            {
                label3.Enabled = true;
                OCRPath.Enabled = true;
                button3.Enabled = true;
            }
            else
            {
                label3.Enabled = false;
                OCRPath.Enabled = false;
                button3.Enabled = false;
            }
        }

        private bool fileExistTest(string path)
        {
            FileInfo fi = new FileInfo(path);
            if (!fi.Exists)
                return false;
            return true;
        }

        private bool directoryExistTest(string path)
        {
            DirectoryInfo fi = new DirectoryInfo(path);
            if (!fi.Exists)
                return false;
            return true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确认退出程序?", "退出", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void readConf()
        {
            try
            {
                using (FileStream fs = new FileStream(confPath, FileMode.Open, FileAccess.Read))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        rarExePath.Text = sr.ReadLine();
                        rarPath.Text = sr.ReadLine();
                        OCRPath.Text = sr.ReadLine();
                    }
                }
            }
            catch (Exception e)
            {
                e.ToString();
            };
        }

        private void writeConf()
        {
            try
            {
                using (FileStream fs = new FileStream(confPath, FileMode.Create))
                {
                    using (StreamWriter sw = new StreamWriter(fs))
                    {
                        sw.WriteLine(rarExePath.Text);
                        sw.WriteLine(rarPath.Text);
                        sw.WriteLine(OCRPath.Text);
                    }
                }
            }
            catch (Exception e)
            {
                e.ToString();
            };
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            writeConf();
        }
    }
}
